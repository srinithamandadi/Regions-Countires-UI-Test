import { Region } from './../../models/region';

export interface RegionState {
    regions: Region[];
}
