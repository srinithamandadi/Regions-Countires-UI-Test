import { Country } from './country';

export class Region {
    public name = '';
    public expanded = false;
    public countries: Country[] = [];
}

