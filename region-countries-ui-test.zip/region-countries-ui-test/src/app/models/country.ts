export class Country {
    public name = '';
    public capital = '';
    public population = 0;
    public currencies: any[] = [];
    public flag = '';
    public expanded = false;
}
